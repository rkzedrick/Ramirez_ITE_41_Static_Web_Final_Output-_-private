const container = document.querySelector('Label1', 'Label2', 'Label3', 'Label4',  'Label5', 'Label6', 'number_adults', 'number_kids');
const cancelBtn = document.getElementById('cancel');
const submitBtn = document.getElementById('submit');


function CheckForm(YourForm) {
    if(YourForm.GivenName.value == "" || YourForm.GivenName.value == null) {
      alert ("Please complete the details in the table!");
      return(false);
    }
    else{
      alert ("You have Successfully Booked your slot!");
      return(true);
    }
  }
  function CheckForm(YourForm) {
    if(YourForm.MiddleName.value == "" || YourForm.MiddleName.value == null) {
      alert ("Please complete the details in the table!");
      return(false);
    }
    else{
      alert ("You have Successfully Booked your slot!");
      return(true);
    }
  }
  function CheckForm(YourForm) {
    if(YourForm.LastName.value == "" || YourForm.LastName.value == null) {
      alert ("Please complete the details in the table!");
      return(false);
    }
    else{
      alert ("You have Successfully Booked your slot!");
      return(true);
    }
  }
  function CheckForm(YourForm) {
    if(YourForm.EmailAddress.value == "" || YourForm.EmailAddress.value == null) {
      alert ("Please complete the details in the table!");
      return(false);
    }
    else{
      alert ("You have Successfully Booked your slot!");
      return(true);
    }
  }function CheckForm(YourForm) {
    if(YourForm.ContactNumber.value == "" || YourForm.ContactNumber.value == null) {
      alert ("Please complete the details in the table!");
      return(false);
    }
    else{
      alert ("You have Successfully Booked your slot!");
      return(true);
    }
  }
  function CheckForm(YourForm) {
    if(YourForm.HomeAddress.value == "" || YourForm.HomeAddress.value == null) {
      alert ("Please complete the details in the table!");
      return(false);
    }
    else{
      alert ("You have Successfully Booked your slot!");
      return(true);
    }

  }function CheckForm(YourForm) {
    if(YourForm.Number_Adults.value == "" || YourForm.Number_Adults.value == null) {
      alert ("Please complete the details in the table!");
      return(false);
    }
    else{
      alert ("You have Successfully Booked your slot!");
      return(true);
    }
  }
  function CheckForm(YourForm) {
    if(YourForm.Number_Kids.value == "" || YourForm.Number_Kids.value == null) {
      alert ("Please complete the details in the table!");
      return(false);
    }
    else{
      alert ("You have Successfully Booked your slot!");
      return(true);
    }
  }
  